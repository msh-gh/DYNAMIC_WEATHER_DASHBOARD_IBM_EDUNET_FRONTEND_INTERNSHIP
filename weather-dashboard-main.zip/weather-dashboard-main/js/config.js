var city = `:auto` // :auto for your estimated location (default). City format can be Lansing,MI or London,UK.
// Types are zipcode, cityname, and geocode.
var client_id = `wgE96YE3scTQLKjnqiMsv`; // This is your client id from aeris weather. Former: DZLMGEFxCvfbQRG7aSN3c
var client_secret = `SVG2gQFV8y9DjKR0BRY9wPoSLvrMrIqF9Lq2IYaY` // This is your client secret from aeris weather. Former: N63dulcmKzQTrWjIrTe2aGKmOw5AhERWWUmjHQKt

// Ignore this
file0 = `index.html`
variable0 = `city`